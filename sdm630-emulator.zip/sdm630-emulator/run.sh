#!/usr/bin/with-contenv bashio
python3 /sdm630_emulator.py
EOF
chmod +x addons/sdm630-emulator/run.sh